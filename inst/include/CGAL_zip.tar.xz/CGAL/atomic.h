// Copyright (c) 2016 GeometryFactory Sarl (France)
//  All rights reserved.
//
// This file is part of CGAL (www.cgal.org)
//
// $URL: https://github.com/CGAL/cgal/blob/v6.2.1/Installation/include/CGAL/atomic.h $
// $Id: include/CGAL/atomic.h 28811b671a1 $
// SPDX-License-Identifier: LGPL-3.0-or-later OR LicenseRef-Commercial

#ifndef CGAL_ATOMIC_H
#define CGAL_ATOMIC_H

#define CGAL_DEPRECATED_HEADER "<CGAL/atomic.h>"
#define CGAL_REPLACEMENT_HEADER "<CGAL/config.h>"
#include <CGAL/Installation/internal/deprecation_warning.h>

#include <CGAL/config.h>

#endif // CGAL_ATOMIC_H
