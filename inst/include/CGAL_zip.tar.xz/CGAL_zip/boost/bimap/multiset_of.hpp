// Copyright (c) 2014
// Utrecht University (The Netherlands),
// ETH Zurich (Switzerland),
// INRIA Sophia-Antipolis (France),
// Max-Planck-Institute Saarbruecken (Germany),
// and Tel-Aviv University (Israel).  All rights reserved.
//
// This file is part of CGAL (www.cgal.org)
//
// $URL: https://github.com/CGAL/cgal/blob/v6.2/Installation/include/CGAL/boost/bimap/multiset_of.hpp $
// $Id: include/CGAL/boost/bimap/multiset_of.hpp cac3e9d75e2 $
// SPDX-License-Identifier: LGPL-3.0-or-later OR LicenseRef-Commercial
//
//
// Author(s)     : Andreas Fabri

#include <boost/config.hpp>

#if defined(BOOST_MSVC)
#  pragma warning(push)
#  pragma warning(disable: 4244 4512)
#endif

#include <boost/bimap/multiset_of.hpp>

#if defined(BOOST_MSVC)
#  pragma warning(pop)
#endif

