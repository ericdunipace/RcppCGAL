// Copyright (c) 2007,2009,2011 Max-Planck-Institute for Computer Science (Germany).
// All rights reserved.
//
// This file is part of CGAL (www.cgal.org).
//
// $URL: https://github.com/CGAL/cgal/blob/v6.2.1/Arrangement_on_surface_2/include/CGAL/Arr_overlay.h $
// $Id: include/CGAL/Arr_overlay.h 28811b671a1 $
// SPDX-License-Identifier: GPL-3.0-or-later OR LicenseRef-Commercial
//
//
// Author(s)     : Eric Berberich <eric@mpi-inf.mpg.de>

#ifndef CGAL_ARR_OVERLAY_H
#define CGAL_ARR_OVERLAY_H

#include <CGAL/license/Arrangement_on_surface_2.h>

#define CGAL_DEPRECATED_HEADER "<CGAL/Arr_overlay.h>"
#define CGAL_REPLACEMENT_HEADER "<CGAL/Arr_overlay_2.h>"
#include <CGAL/Installation/internal/deprecation_warning.h>

#include <CGAL/Arr_overlay_2.h>

/*! \file
 * Helping file to include Arr_overlay_2 for backward compatibility.
 */

#include <CGAL/Arr_overlay_2.h>

#endif

